<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project UTS Group 6</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="wrapper">
            <div class="logo"><a href=''><img src="img/Polines.png" width="250" height="70"></a></div>
            <div class="menu">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="soal1.php">Soal 1</a></li>
                    <li><a href="soal2.php">Soal 2</a></li>
                    <li><a href="soal3.php">Soal 3</a></li>
                    <li><a href="soal4.php">Soal 4</a></li>
                </ul>
            </div>
        </div>
    </nav>
</body>
</html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project UTS Group 6</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
	include ("header.php");
	?>

    <div class="wrapper">
        <section id="home">
            <img src="img/team2.png" width="600" height="300"/>
            <div class="kolom">
                <p class="deskripsi">Kelas IK-2E</p>
                <h2>Kelompok 6</h2>
                <p>Tahun 2021/2022</p>
            </div>
        </section>
        
        <section id="courses">
        <div class="kolom">
            <p class="deskripsi">Soal 1</p>
            <h2>Program Penghitung Nilai IPK</h2>
            <p>Program untuk menghitung nilai dan menentukan predikat IPK Mahasiswa.</p>
            <p><a href="soal1.php" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
        </div>
        <img src="img/graduate.png"  width="450" height="330"/>
        </section>

        
            <section id="home">
                <img src="img/nilai.png"  width="400" height="350"/>
                <div class="kolom">
                    <p class="deskripsi">Soal 2</p>
                    <h2>Program Penghitung Nilai Rata-Rata Siswa, Mata Pelajaran, & Menentukan Jurusan</h2>
                    <p>Program untuk menghitung rata-rata siswa, mata pelajaran, dan menentukan jurusan.</p>
                    <p><a href="soal2.php" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
                </div>
            </section>

        <section id="courses">
            <div class="kolom">
                <p class="deskripsi">Soal 3</p>
                <h2>Program Penghitung Luas & Keliling Bangun Datar</h2>
                <p>Program untuk menghitung luas dan keliling bangun datar yang terdiri dari Lingkaran, Persegi, Segitiga, Jajar Genjang, dan Layang-Layang.</p>
                <p><a href="soal3.php" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
            </div>
            <img src="img/logo.png" width="350" height="350"/>
        </section>

        
            <section id="home">
                <img src="img/bgruang1.png"  width="450" height="350"/>
                <div class="kolom">
                    <p class="deskripsi">Soal 4</p>
                    <h2>Program Penghitung Luas, Keliling, & Volume Bangun Ruang</h2>
                    <p>Program untuk menghitung luas, keliling, dan volume bangun ruang yang terdiri dari Balok, Tabung, Bola, dan Kerucut.</p>
                    <p><a href="soal4.php" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
                </div>
            </section>
        </div>

    <?php
	include ("footer.php");
	?>
    
</body>
</html>
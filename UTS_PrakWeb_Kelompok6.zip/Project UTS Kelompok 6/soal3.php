<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rumus Bangun Datar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
	include ("header.php");
	?>

	<?php
	include ("menubangundatar.php");
	?>

	<div class="wrapper">
        <section id="home">
            <img src="img/logo.png" width="400" height="350">
            <div class="kolom">
                <p class="deskripsi">Kelas IK-2E</p>
                <h2>RUMUS BANGUN DATAR</h2>
                <p>by. Kelompok 6</p>
            </div>
        </section>
    </div>

	<?php
	include ("footer.php");
	?>
    
</body>
</html>
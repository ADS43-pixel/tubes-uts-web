<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project UTS Group 6</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div id="contact">
        <div class="wrapper">
            <div class="footer">
                <div class="footer-section">
                    <img src="img/book.png" height="80" width="80"><br><br>
                    <p><a href="bukutamu.php" class="tbl-biru">Buku Tamu</a></p>
                </div>
                <div class="footer-section">
                    <img src="img/kelompok.png" height="95" width="100">
                    <p><a href="kelompok.php" class="tbl-biru">Anggota Kelompok</a></p>
                </div>
                <div class="footer-section">
                    <img src="img/polines2.png" height="75" width="80"><br><br>
                    <p><a href="http://polines.ac.id/" class="tbl-biru">Polines</a></p>
                </div>
                <div id="copyright">
                &copy; 2021. <b>Kelompok 6.</b> All Rights Reserved.
                </div>
            </div>
        </div>
    </div>
</body>
</html>